
import { piecesRender } from './services/piecesRender.service.js'

addEventListener( 'DOMContentLoaded', _ => {
    piecesRender.renderPieces()
})
